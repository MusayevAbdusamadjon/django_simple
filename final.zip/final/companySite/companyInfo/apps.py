from django.apps import AppConfig


class CompanyinfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'companyInfo'
