from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from .forms import EmployeeForm, NewsPostForm, SignUpForm
from .models import Employee, NewsPost

def home(request):
    employees = Employee.objects.all()
    news_posts = NewsPost.objects.all()
    return render(request, 'companyInfo/home.html', {'employees': employees, 'news_posts': news_posts})

@login_required
def add_employee(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = EmployeeForm()
    return render(request, 'companyInfo/add_employee.html', {'form': form})

@login_required
def edit_employee(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == 'POST':
        form = EmployeeForm(request.POST, request.FILES, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = EmployeeForm(instance=employee)
    return render(request, 'companyInfo/edit_employee.html', {'form': form, 'employee': employee})

@login_required
def delete_employee(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == 'POST':
        employee.delete()
        return redirect('home')
    return render(request, 'companyInfo/delete_employee.html', {'employee': employee})

@login_required
def add_news_post(request):
    if request.method == 'POST':
        form = NewsPostForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = NewsPostForm()
    return render(request, 'companyInfo/add_news_post.html', {'form': form})

@login_required
def edit_news_post(request, pk):
    post = get_object_or_404(NewsPost, pk=pk)
    if request.method == 'POST':
        form = NewsPostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = NewsPostForm(instance=post)
    return render(request, 'companyInfo/edit_news_post.html', {'form': form, 'post': post})

@login_required
def delete_news_post(request, pk):
    post = get_object_or_404(NewsPost, pk=pk)
    if request.method == 'POST':
        post.delete()
        return redirect('home')
    return render(request, 'companyInfo/delete_news_post.html', {'post': post})

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('home')
    else:
        form = SignUpForm()
    return render(request, 'companyInfo/signup.html', {'form': form})